#!/usr/bin/env python3
import sys
import os
from PIL import Image, ImageOps

TARGET_SIZE = (128, 128)   # <<< CHANGE WAS 256,256
NUM_COLORS  = 256

def make_mem(input_fname, base_name):
    os.makedirs("data", exist_ok=True)

    # Load and resize
    image_in = Image.open(input_fname).convert("RGB")
    w, h = image_in.size
    print(f"[{base_name}] original {input_fname} is {w}x{h}")

    # Resize to 128x128 (keep it pixel-y)
    image_resized = image_in.resize(TARGET_SIZE, Image.NEAREST)

    # Quantize to 256-color palette
    image_pal = image_resized.convert(
        mode="P",
        palette=Image.ADAPTIVE,
        colors=NUM_COLORS
    )

    # Save a preview to visually check
    preview_name = f"preview_{base_name}.png"
    image_pal.save(preview_name)
    print(f"[{base_name}] resized to {TARGET_SIZE[0]}x{TARGET_SIZE[1]} "
          f"and reducing to {NUM_COLORS} colors")
    print(f"[{base_name}] preview saved to {preview_name}")

    # --- WRITE IMAGE INDEX MEM (one 8-bit index per pixel) ---
    pixels = list(image_pal.getdata())
    img_mem_path = os.path.join("data", f"{base_name}_image.mem")
    with open(img_mem_path, "w") as f:
        for p in pixels:
            f.write(f"{p:02X}\n")
    print(f"[{base_name}] wrote image indices to {img_mem_path}")

    # --- WRITE PALETTE MEM (256 entries, 8-bit per channel) ---
    pal = image_pal.getpalette()[:NUM_COLORS * 3]  # R,G,B triples
    pal_mem_path = os.path.join("data", f"{base_name}_sprite.mem")
    with open(pal_mem_path, "w") as f:
        for i in range(NUM_COLORS):
            r = pal[3*i + 0]
            g = pal[3*i + 1]
            b = pal[3*i + 2]
            # 24-bit RGB: RRGGBB
            f.write(f"{r:02X}{g:02X}{b:02X}\n")
    print(f"[{base_name}] wrote palette to {pal_mem_path}")


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(f"Usage: {sys.argv[0]} <image.png> <base_name>")
        sys.exit(1)

    input_fname = sys.argv[1]
    base_name   = sys.argv[2]
    make_mem(input_fname, base_name)
