`timescale 1ns / 1ps
`default_nettype none

module renderer #(
    parameter GRID_W = 40,
    parameter GRID_H = 40,
    parameter CELL_W = 16,   // 640/40
    parameter CELL_H = 18,   // 720/40
    parameter PLAYER_R = 21
)(
    input  wire        clk,
    input  wire        active,
    input  wire [2:0]  game_state,
    input  wire        blink_p1,
    input  wire        blink_p2,

    // theme: 0 = red/blue, 1 = purple/green
    input  wire        theme,

    input  wire [GRID_W*GRID_H-1:0] path_p1,
    input  wire [GRID_W*GRID_H-1:0] path_p2,

    input  wire [10:0] x,
    input  wire [9:0]  y,

    // COM
    input  wire [10:0] p1_x,
    input  wire [9:0]  p1_y,
    input  wire [10:0] p2_x,
    input  wire [9:0]  p2_y,

    // lives
    input  wire [1:0] p1_lives,
    input  wire [1:0] p2_lives,

    // winner (GAME_OVER)
    input  wire [1:0] winner,

    output logic [7:0] R,
    output logic [7:0] G,
    output logic [7:0] B
);

    // ================================
    //  Grid Cell Decode
    // ================================
    logic [$clog2(GRID_W)-1:0] cx;
    logic [$clog2(GRID_H)-1:0] cy;
    integer addr_p1, addr_p2;

    always_comb begin
        cx = x / CELL_W;
        cy = y / CELL_H;
        addr_p1 = cy*GRID_W + cx;
        addr_p2 = cy*GRID_W + cx;
    end

    // path bits
    logic on_p1, on_p2;
    assign on_p1 = path_p1[addr_p1];
    assign on_p2 = path_p2[addr_p2];

    // ================================
    //  Player circles
    // ================================
    function logic inside_circle(input int px, py, cx, cy, r);
        inside_circle = ((px-cx)*(px-cx) + (py-cy)*(py-cy)) <= (r*r);
    endfunction

    logic draw_p1_circle = inside_circle(x, y, p1_x, p1_y, PLAYER_R);
    logic draw_p2_circle = inside_circle(x, y, p2_x, p2_y, PLAYER_R);

    // ================================
    //  Life hearts (as circle clusters)
    // ================================
    // Player1 lives at (40, 650 + offset)
    // Player2 lives at (40, 700 + offset)

    function logic inside_heart(
        input int px, py,
        input int cx, cy
    );
        inside_heart =
            ((px-cx)*(px-cx) + (py-cy)*(py-cy)) <= 12*12;
    endfunction

    logic heart_p1_0, heart_p1_1, heart_p1_2;
    logic heart_p2_0, heart_p2_1, heart_p2_2;

    always_comb begin
        heart_p1_0 = (p1_lives >= 1) ? inside_heart(x,y, 40, 650) : 1'b0;
        heart_p1_1 = (p1_lives >= 2) ? inside_heart(x,y, 70, 650) : 1'b0;
        heart_p1_2 = (p1_lives == 3) ? inside_heart(x,y,100, 650) : 1'b0;

        heart_p2_0 = (p2_lives >= 1) ? inside_heart(x,y, 40,700) : 1'b0;
        heart_p2_1 = (p2_lives >= 2) ? inside_heart(x,y, 70,700) : 1'b0;
        heart_p2_2 = (p2_lives == 3) ? inside_heart(x,y,100,700) : 1'b0;
    end

    logic draw_life =
        heart_p1_0 | heart_p1_1 | heart_p1_2 |
        heart_p2_0 | heart_p2_1 | heart_p2_2;

    // ================================
    //  Text Rendering (Winner / Menu)
    // Simple block-font rectangle letters
    // ================================
    function logic block_letter(
        input int px, py,
        input int x0, y0,
        input int w, input int h
    );
        block_letter = (px>=x0 && px<x0+w && py>=y0 && py<y0+h);
    endfunction

    logic draw_menu_text;
    logic draw_win_text;

    always_comb begin
        draw_menu_text =
            (game_state==3'd0) && block_letter(x,y, 500, 200, 280, 40);

        draw_win_text =
            (game_state==3'd4) && block_letter(x,y, 520, 200, 240, 40);
    end

    // ================================
    //  PATH COLORS per theme
    // ================================
    logic [7:0] p1_R, p1_G, p1_B;
    logic [7:0] p2_R, p2_G, p2_B;

    always_comb begin
        if (!theme) begin
            // theme 0 = red / blue
            p1_R = 8'hC0; p1_G = 8'h10; p1_B = 8'h10;
            p2_R = 8'h10; p2_G = 8'h10; p2_B = 8'hC0;
        end else begin
            // theme 1 = purple / green
            p1_R = 8'hA0; p1_G = 8'h20; p1_B = 8'hA0;
            p2_R = 8'h20; p2_G = 8'hA0; p2_B = 8'h20;
        end
    end

    // ================================
    //  RENDER PIPELINE
    // ================================
    always_comb begin
        // background = black
        R = 0; G = 0; B = 0;

        if (!active) begin
            R = 0; G = 0; B = 0;
        end

        // MENU SCREEN
        else if (game_state == 3'd0) begin
            // preview colors from current switch selection
            if (on_p1) begin R=p1_R; G=p1_G; B=p1_B; end
            else if (on_p2) begin R=p2_R; G=p2_G; B=p2_B; end

            if (draw_menu_text)
                {R,G,B} = {8'hFF, 8'hFF, 8'hFF};
        end

        // READY + PLAY + LIFE_LOSS
        else if (game_state == 3'd1 ||
                 game_state == 3'd2 ||
                 game_state == 3'd3)
        begin
            // PATHS
            if (on_p1) begin R=p1_R; G=p1_G; B=p1_B; end
            else if (on_p2) begin R=p2_R; G=p2_G; B=p2_B; end

            // PLAYER CIRCLES
            if (draw_p1_circle && !(game_state==3'd3 && blink_p1)) begin
                R = 8'hFF; G=8'hFF; B=8'hFF;
            end
            if (draw_p2_circle && !(game_state==3'd3 && blink_p2)) begin
                R = 8'hFF; G=8'hFF; B=8'h00;
            end

            // LIVES
            if (draw_life)
                {R,G,B} = {8'hFF,20,20};
        end

        // GAME OVER
        else if (game_state == 3'd4) begin
            if (on_p1) begin R=p1_R; G=p1_G; B=p1_B; end
            else if (on_p2) begin R=p2_R; G=p2_G; B=p2_B; end

            if (draw_win_text)
                {R,G,B} = (winner==1) ? {8'hFF, 0,0} : {0,8'hFF,0};

            if (draw_life)
                {R,G,B} = {8'hFF,20,20};
        end
    end

endmodule

`default_nettype wire
