import cocotb
import os
import sys
from math import log
import logging
from pathlib import Path
from cocotb.clock import Clock
from cocotb.triggers import Timer, ClockCycles, RisingEdge, FallingEdge, ReadOnly, with_timeout
from cocotb.utils import get_sim_time as gst
from cocotb.runner import get_runner

test_file = os.path.basename(__file__).replace(".py", "")


@cocotb.test()
async def test_a(dut):
    """cocotb test for game_fsm"""
    dut._log.info("Starting game_fsm test...")

    # Start clock
    cocotb.start_soon(Clock(dut.clk, 10, units="ns").start())

    # Default inputs
    dut.rst.value          = 1
    dut.new_frame.value    = 0
    dut.p1_life_lost.value = 0
    dut.p2_life_lost.value = 0
    dut.p1_com_valid.value = 0
    dut.p2_com_valid.value = 0
    dut.start_game.value   = 0

    await ClockCycles(dut.clk, 5)
    dut.rst.value = 0
    await ClockCycles(dut.clk, 5)

    # Try to read parameters from DUT, fallback to defaults
    try:
        lives_init = int(dut.LIVES)
    except AttributeError:
        lives_init = 3

    try:
        pause_frames = int(dut.PAUSE_FRAMES)
    except AttributeError:
        pause_frames = 120

    try:
        blink_period = int(dut.BLINK_PERIOD)
    except AttributeError:
        blink_period = 15

    # State encoding (matches enum in RTL)
    INIT      = 0
    READY     = 1
    PLAY      = 2
    LIFE_LOSS = 3
    GAME_OVER = 4

    # --- After reset: should be INIT with full lives ---
    await ClockCycles(dut.clk, 1)
    state = int(dut.state.value)
    p1_lives = int(dut.p1_lives.value)
    p2_lives = int(dut.p2_lives.value)

    dut._log.info(f"After reset: state={state}, p1_lives={p1_lives}, p2_lives={p2_lives}")
    assert state == INIT, f"Expected INIT={INIT} after reset, got {state}"
    assert p1_lives == lives_init and p2_lives == lives_init, "Lives not initialized correctly"

    # --- Move INIT -> READY via start_game ---
    dut.start_game.value = 1
    await ClockCycles(dut.clk, 1)
    dut.start_game.value = 0
    await ClockCycles(dut.clk, 1)
    state = int(dut.state.value)
    dut._log.info(f"After start_game pulse: state={state}")
    assert state == READY, f"Expected READY={READY}, got {state}"

    # --- READY phase: show each player valid & on-path at least once ---
    # P1 gets valid first
    for _ in range(3):
        dut.p1_com_valid.value = 1
        dut.p1_life_lost.value = 0
        dut.p2_com_valid.value = 0
        dut.p2_life_lost.value = 0
        await ClockCycles(dut.clk, 1)
    dut.p1_com_valid.value = 0

    # Then P2
    for _ in range(3):
        dut.p2_com_valid.value = 1
        dut.p2_life_lost.value = 0
        await ClockCycles(dut.clk, 1)
    dut.p2_com_valid.value = 0

    # Give FSM a few cycles to transition to PLAY
    for _ in range(5):
        await ClockCycles(dut.clk, 1)

    state = int(dut.state.value)
    dut._log.info(f"After READY handshake: state={state}")
    assert state == PLAY, f"Expected PLAY={PLAY} after both players ready, got {state}"

    # Helper: cause a life loss for P1 and wait through LIFE_LOSS pause
    async def do_p1_life_loss(expected_lives_after):
        # Trigger life loss
        dut.p1_life_lost.value = 1
        dut.p2_life_lost.value = 0
        await ClockCycles(dut.clk, 1)
        dut.p1_life_lost.value = 0

        await ClockCycles(dut.clk, 1)
        s = int(dut.state.value)
        dut._log.info(f"After P1 life loss trigger: state={s}, p1_lives={int(dut.p1_lives.value)}")
        assert s == LIFE_LOSS, f"Expected LIFE_LOSS={LIFE_LOSS} after hit, got {s}"
        assert int(dut.p1_lives.value) == expected_lives_after, (
            f"Expected p1_lives={expected_lives_after}, got {int(dut.p1_lives.value)}"
        )

        # During LIFE_LOSS, blink_p1 should toggle; blink_p2 stays low
        saw_blink = False
        for i in range(pause_frames):
            # new_frame pulse
            dut.new_frame.value = 1
            await ClockCycles(dut.clk, 1)
            dut.new_frame.value = 0
            await ClockCycles(dut.clk, 0)

            if int(dut.blink_p1.value) == 1:
                saw_blink = True
            assert int(dut.blink_p2.value) == 0, "blink_p2 should remain low when only P1 was hit"

        dut._log.info(f"Blink_p1 active during LIFE_LOSS? {saw_blink}")
        assert saw_blink, "Expected blink_p1 to toggle at least once during LIFE_LOSS"

        # After PAUSE_FRAMES, FSM should go back to PLAY (if lives > 0) or GAME_OVER (if 0)
        await ClockCycles(dut.clk, 2)
        return int(dut.state.value)

    # --- First life loss: P1 from 3 -> 2, should return to PLAY ---
    state = await do_p1_life_loss(lives_init - 1)
    dut._log.info(f"State after first LIFE_LOSS phase: {state}")
    assert state == PLAY, f"Expected PLAY={PLAY} after LIFE_LOSS with lives remaining, got {state}"

    # --- Second life loss: P1 from 2 -> 1 ---
    state = await do_p1_life_loss(lives_init - 2)
    dut._log.info(f"State after second LIFE_LOSS phase: {state}")
    assert state == PLAY, f"Expected PLAY={PLAY} after second LIFE_LOSS with lives remaining, got {state}"

    # --- Third life loss: P1 from 1 -> 0, should end in GAME_OVER with P2 as winner ---
    state = await do_p1_life_loss(lives_init - 3)
    await ClockCycles(dut.clk, 2)
    state = int(dut.state.value)
    w = int(dut.winner.value)
    p1_lives = int(dut.p1_lives.value)
    p2_lives = int(dut.p2_lives.value)

    dut._log.info(f"Final state={state}, winner={w}, p1_lives={p1_lives}, p2_lives={p2_lives}")
    assert state == GAME_OVER, f"Expected GAME_OVER={GAME_OVER}, got {state}"
    assert p1_lives == 0, "Expected P1 lives to be 0 at GAME_OVER"
    assert w == 2, f"Expected winner=2 (P2 wins when P1 dies), got {w}"


def game_fsm_runner():
    """Game FSM Tester."""
    hdl_toplevel_lang = os.getenv("HDL_TOPLEVEL_LANG", "verilog")
    sim = os.getenv("SIM", "icarus")
    proj_path = Path(__file__).resolve().parent.parent

    sys.path.append(str(proj_path / "sim" / "model"))

    sources = [proj_path / "hdl" / "game_fsm.sv"]

    build_test_args = ["-Wall"]
    parameters = {}
    hdl_toplevel = "game_fsm"

    sys.path.append(str(proj_path / "sim"))
    runner = get_runner(sim)
    runner.build(
        sources=sources,
        hdl_toplevel=hdl_toplevel,
        always=True,
        build_args=build_test_args,
        parameters=parameters,
        timescale=('1ns', '1ps'),
        waves=True
    )
    run_test_args = []
    runner.test(
        hdl_toplevel=hdl_toplevel,
        test_module=test_file,
        test_args=run_test_args,
        waves=True
    )


if __name__ == "__main__":
    game_fsm_runner()
