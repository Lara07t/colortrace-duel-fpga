module cocotb_iverilog_dump();
initial begin
    $dumpfile("/home/lara/fa25-6205-team17/sim/sim_build/autopath_gen.fst");
    $dumpvars(0, autopath_gen);
end
endmodule
